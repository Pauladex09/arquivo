import React from "react";
import { View, StyleSheet,  Text,  TextInput,  Image, Button, ScroolView, ImageBackground } from "react-native";
import { StatusBar } from "expo-status-bar";
import ListaX from "./lista";

export default function App() {
  return (

     <ImageBackground
          source={require("./assets/fundo.jpg")}
          style={styles.background}
          resizeMode="cover"
        >
    
    <View style={styles.container}>
      <ListaX />
      <StatusBar style="auto" />
    </View>

    </ImageBackground>
  );
}
// app.js
const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
  container: {
    flex: 1,
    paddingHorizontal: 10,
    paddingTop: 40, // espaço para não colar no topo
  },
});

