import React, { useState } from "react";
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image, Modal, Pressable } from "react-native";

export default function ListaX() {
  const [itemSelecionado, setItemSelecionado] = useState(null);

  const produtos = [
    { id: "1", nome: "Notebook", fabricante: "Intel", preco: "4500.00", desc: "Notebook potente para trabalho e jogos.", imagem: require("./assets/notebook.avif") },
    { id: "2", nome: "Mouse", fabricante: "Logitech", preco: "150.00", desc: "Mouse ergonômico e preciso.", imagem: require("./assets/mouse.webp") },
    { id: "3", nome: "Teclado", fabricante: "Razer", preco: "350.00", desc: "Teclado mecânico gamer.", imagem: require("./assets/teclado.avif") },
    { id: "4", nome: "Monitor", fabricante: "Samsung", preco: "1200.00", desc: "Monitor 27 polegadas, Full HD.", imagem: require("./assets/monitor.webp") },
    { id: "5", nome: "Fone de Ouvido", fabricante: "Sony", preco: "800.00", desc: "Fone de ouvido com cancelamento de ruído.", imagem: require("./assets/fone.jpg") },
    { id: "6", nome: "Webcam", fabricante: "Logitech", preco: "300.00", desc: "Webcam HD para videochamadas.", imagem: require("./assets/webcam.jpg") },
    { id: "7", nome: "Cadeira Gamer", fabricante: "DXRacer", preco: "1200.00", desc: "Cadeira ergonômica para longas sessões de jogo.", imagem: require("./assets/cadeira.webp") },
  ];

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={produtos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.item} onPress={() => setItemSelecionado(item)}>
          <Text>ID: {item.id}</Text>
            <Text style={styles.nome}>{item.nome}</Text>
            <Text>{item.fabricante}</Text>
            <Text>R$ {item.preco}</Text>
          </TouchableOpacity>
        )}
      />

      <Modal visible={!!itemSelecionado} transparent={true} animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            {itemSelecionado && (
              <>
                <Image source={itemSelecionado.imagem} style={styles.imagem} />
                <Text style={styles.modalTitulo}>{itemSelecionado.nome}</Text>
                <Text style={styles.modalDesc}>{itemSelecionado.desc}</Text>
                <Pressable style={styles.fecharBtn} onPress={() => setItemSelecionado(null)}>
                  <Text style={styles.fecharTxt}>Fechar</Text>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    padding: 15,
    marginVertical: 8,
    marginHorizontal: 16,
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  nome: {
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 4,
    color: "#222",
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "85%",
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  imagem: {
    width: "100%",
    height: 200,
    borderRadius: 15,
    marginBottom: 15,
  },
  modalTitulo: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  modalDesc: {
    fontSize: 16,
    color: "#555",
    textAlign: "center",
    marginBottom: 20,
  },
  fecharBtn: {
    backgroundColor: "#00CED1",
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 12,
  },
  fecharTxt: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
});
